-Start fresh VMD session
-Upload both the autopsf.pdb and autopsf.psf into VMD (make sure you select new molecule each time you import a file).
-Start NAMD Energy in Extension/Analysis
-Run using the autopsf.psf file first using the specified parameters. You will hit an error message. Then run it again using the autopsf.pdb file. It should output the results in this directory (NamdEnergyAssignment/VMD/) with the specified name. The results should appear within seconds.

Parameters:
	Molecule: (First use xxxx_autopsf.psf, then after the error, select xxxx_autopsf.pdb)
	
	Selection 1 (example): protein and chain B
	Selection 2 (example): protein and chain F

	Output File: output.txt (or whatever you want to name it)
	
	Parameter Files: 
		Click "Find" and follow the path located in this directory: 
		NamdEnergyAssignment/VMD/plugins/noarch/tcl/readcharmmpar1.3/par_all36_prot.prm


*If VMD asks you to specify a path to NAMD2, select NAMD2.exe within the NAMD_2.14b2 folder in this directory.


https://phcompeau.github.io/biological_modeling_course/coronavirus/tutorial_NAMD

