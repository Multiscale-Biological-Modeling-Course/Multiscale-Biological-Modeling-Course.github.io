'''
FILE:   ShapeSpaceByCellType.py
NAME:   N. Matamala
STRT:   04.16.2019; 5:15 PM
UPDT:   07.11.2019; 2:05 AM
'''

import numpy as np
from scipy.spatial.distance import pdist, squareform
import csv
import matplotlib.pyplot as plt
from sklearn import manifold
from mpl_toolkits.mplot3d import Axes3D
import sys
import os
import math
import itertools
import random 
import pandas as pd

"""This function reads the file where the distance matrix is saved"""
def Read_Matrix(filename):

  # Reads the file and parse the matrix from it  
  reader = csv.reader(open(filename, "r"), delimiter=',')
  data = list(reader)
  dists = []
  labels = []

  for d in data[1:]:
       dists.append(list(map(lambda x: float(x), d[3:6])))
       labels.append(str(d[2]))

  # contains the matrix (len(adist) gives me the dimensions of the matrix)    
  adist = np.array(dists)

  # maximum value distance in the matrix
  amax = np.amax(adist)

  # This is the distance matrix
  adist /= amax   

  # returns matrix
  return (adist, labels)

def plot3D(filename):
  (mat, labels) = Read_Matrix(filename)

  fig = plt.figure()
  ax = Axes3D(fig)

  for i in range(len(mat)):
    x = mat[i][0]
    y = mat[i][1]
    z = mat[i][2]
    l = labels[i]

    if l == 'BASOPHIL': labelColor = 'springgreen'  
    elif l == 'EOSINOPHIL': labelColor = 'midnightblue'
    elif l == 'LYMPHOCYTE': labelColor = '#0093D1'
    elif l == 'MONOCYTE': labelColor = '#F2635F'
    elif l == 'NEUTROPHIL': labelColor = '#E0A025'
    else: 
      l = 'OTHER'
      labelColor = 'darkgrey'

    ax.scatter(x, y, z, c=labelColor)
    plt.subplots_adjust(bottom = 0.1)
    
  ax.scatter(0, 0, 0, c='springgreen', label='BASOPHIL')
  ax.scatter(0, 0, 0, c='midnightblue', label='EOSINOPHIL')
  ax.scatter(0, 0, 0, c='#0093D1', label='LYMPHOCYTE')
  ax.scatter(0, 0, 0, c='#F2635F', label='MONOCYTE')
  ax.scatter(0, 0, 0, c='#E0A025', label='NEUTROPHIL')
  # ax.scatter(0, 0, 0, c='darkgrey', label='OTHER')
  ax.scatter(0, 0, 0, c='white')

  plt.legend(loc=3)
  plt.title(" WBC in CellOrganizer PCA Model by Cell Type")
  plt.savefig('WBC_ShapeSpace_CT.png')
  plt.show()

# Plot the following WBC PCA model
plot3D('WBC_PCA.csv')



